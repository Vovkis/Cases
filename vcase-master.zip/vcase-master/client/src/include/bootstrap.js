import './jquery';
import './popper';

import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
